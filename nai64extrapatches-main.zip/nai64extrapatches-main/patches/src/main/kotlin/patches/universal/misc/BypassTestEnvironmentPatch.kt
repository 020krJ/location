package patches.universal.misc

import app.morphe.patcher.patch.bytecodePatch
import java.util.logging.Logger

@Suppress("unused")
val bypassTestEnvironmentPatch = bytecodePatch(
    name = "Bypass Test Environment",
    description = "Hides test and automation environment.",
    default = false,
) {
    category("Bypass")
    execute {
        val logger = Logger.getLogger(this::class.java.name)
        val patched = foldBooleanReturns(
            mapOf(
                "Landroid/app/ActivityManager;" to mapOf(
                    "isUserAMonkey" to "0x0",
                    "isRunningInTestHarness" to "0x0",
                ),
            ),
        )
        if (patched > 0) logger.info("Forced $patched test-environment check(s) to false")
        else logger.warning("No test-environment checks found. No changes applied.")
    }
}
