package patches.universal.misc

import app.morphe.patcher.extensions.InstructionExtensions.replaceInstruction
import app.morphe.patcher.patch.BytecodePatchContext
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import patches.universal.ads.util.findMutableMethodOf

/**
 * Forces every matching method call to a constant by folding the invoke and its
 * following move-result into a single const/4.
 *
 * [targets] maps definingClass -> set of method names -> smali constant ("0x0"/"0x1").
 * [returnType] selects which descriptor type must match: "Z" for booleans (default)
 * or "I" for int-returning checks such as biometric error codes.
 *
 * @return number of patched call sites.
 */
internal fun BytecodePatchContext.foldBooleanReturns(
    targets: Map<String, Map<String, String>>,
    returnType: String = "Z",
): Int {
    var patched = 0
    classDefForEach { classDef ->
        var hasRef = false
        for (m in classDef.methods) {
            val impl = m.implementation ?: continue
            for (insn in impl.instructions) {
                val ref = (insn as? ReferenceInstruction)?.reference as? MethodReference ?: continue
                if (targets[ref.definingClass]?.containsKey(ref.name) == true && ref.returnType == returnType) { hasRef = true; break }
            }
            if (hasRef) break
        }
        if (!hasRef) return@classDefForEach
        val mutableClass by lazy { mutableClassDefBy(classDef) }
        for (method in classDef.methods) {
            val mutableMethod by lazy { mutableClass.findMutableMethodOf(method) }
            val implementation = method.implementation ?: continue
            // Snapshot; one-for-one replacements keep indices valid.
            val instructions = implementation.instructions.toList()
            for ((index, instruction) in instructions.withIndex()) {
                val reference =
                    (instruction as? ReferenceInstruction)?.reference as? MethodReference
                        ?: continue

                val value = targets[reference.definingClass]?.get(reference.name) ?: continue
                if (reference.returnType != returnType) continue

                val next = instructions.getOrNull(index + 1) as? OneRegisterInstruction
                if (next != null && next.opcode == Opcode.MOVE_RESULT) {
                    mutableMethod.replaceInstruction(index, "const/4 v${next.registerA}, $value")
                    mutableMethod.replaceInstruction(index + 1, "nop")
                } else {
                    mutableMethod.replaceInstruction(index, "nop")
                }
                patched++
            }
        }
    }
    return patched
}
