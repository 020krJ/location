package patches.universal.misc

import app.morphe.patcher.patch.bytecodePatch
import java.util.logging.Logger

@Suppress("unused")
val spoofSensorListPatch = bytecodePatch(
    name = "Spoof Sensor List",
    description =
        "Forces SensorManager.getSensorList() to return an empty list so apps cannot " +
            "enumerate the device's sensors for fingerprinting or capability checks.",
    default = false,
) {
    category("Spoof")
    execute {
        val logger = Logger.getLogger(this::class.java.name)

        val patched = replaceGetterWithStaticCall(
            definingClass = "Landroid/hardware/SensorManager;",
            methodNames = setOf("getSensorList"),
            returnType = "Ljava/util/List;",
            replacementInvoke =
                "invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;",
        )

        if (patched > 0) {
            logger.info("Spoofed $patched sensor-list read(s)")
        } else {
            logger.warning("No sensor-list reads found. No changes applied.")
        }
    }
}
