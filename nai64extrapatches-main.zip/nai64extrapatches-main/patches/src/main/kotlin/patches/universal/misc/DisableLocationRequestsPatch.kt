package patches.universal.misc

import app.morphe.patcher.patch.bytecodePatch
import java.util.logging.Logger

@Suppress("unused")
val disableLocationRequestsPatch = bytecodePatch(
    name = "Disable Location Requests",
    description = "Stops the app from tracking your location.",
    default = false,
) {
    category("Disable")
    execute {
        val logger = Logger.getLogger(this::class.java.name)
        val patched = noOpVoidInvoke(
            "Landroid/location/LocationManager;",
            setOf("requestLocationUpdates", "requestSingleUpdate"),
        ) + noOpVoidInvoke(
            "Lcom/google/android/gms/location/FusedLocationProviderClient;",
            setOf("requestLocationUpdates"),
        )
        if (patched > 0) logger.info("Neutralized $patched location-request call(s)")
        else logger.warning("No location-request calls found. No changes applied.")
    }
}
