package patches.universal.misc

import app.morphe.patcher.patch.bytecodePatch
import java.util.logging.Logger

@Suppress("unused")
val disableCameraShutterSoundPatch = bytecodePatch(
    name = "Disable Camera Shutter Sound",
    description = "Silences the camera shutter and video-record sounds by neutralizing MediaActionSound.play(...) and Camera.playSound(...).",
    default = false,
) {
    category("Disable")
    execute {
        val logger = Logger.getLogger(this::class.java.name)
        val patched = noOpVoidInvoke("Landroid/media/MediaActionSound;", setOf("play")) +
            noOpVoidInvoke("Landroid/hardware/Camera;", setOf("playSound"))
        if (patched > 0) logger.info("Silenced $patched camera sound call(s)")
        else logger.warning("No camera sound calls found. No changes applied.")
    }
}
