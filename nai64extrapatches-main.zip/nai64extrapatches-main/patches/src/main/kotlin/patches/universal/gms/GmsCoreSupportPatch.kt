package patches.universal.gms

import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.resourcePatch
import app.morphe.patcher.patch.stringOption
import org.w3c.dom.Element
import java.util.logging.Logger

private const val GMS_CORE_SPOOF_MANIFEST = "gmsCoreSpoofManifest"
private const val GMS_CORE_SPOOF_CODE = "gmsCoreSpoofCode"

private val gmsCoreManifestPatch = resourcePatch(
    name = "GmsCore support (MicroG) manifest",
    description = "Adds queries for MicroG and optional package name override for GmsCore routing",
    default = false,
) {
    category("Google Services")
    execute {
        val logger = Logger.getLogger(this::class.java.name)
        document("AndroidManifest.xml").use { manifest ->
            val root = manifest.documentElement
            // Add queries for MicroG package so PackageManager can resolve it on Android 11+
            val packageName = "app.revanced.android.gms" // default, will be overridden by option at runtime if needed
            // Check if queries already exists
            var queries = root.getElementsByTagName("queries").item(0) as? Element
            if (queries == null) {
                queries = manifest.createElement("queries")
                val app = root.getElementsByTagName("application").item(0) as? Element
                if (app != null) root.insertBefore(queries, app) else root.appendChild(queries)
            }
            // Add package query for MicroG if not already present
            var hasGmsQuery = false
            val packages = queries.getElementsByTagName("package")
            for (i in 0 until packages.length) {
                val el = packages.item(i) as? Element ?: continue
                val name = el.getAttributeNS("http://schemas.android.com/apk/res/android", "name")
                    .takeIf { it.isNotEmpty() } ?: el.getAttribute("android:name")
                if (name == packageName || name == "app.morphe.android.gms" || name == "org.microg.gms" || name == "com.google.android.gms" || name == "com.mgoogle.android.gms") {
                    hasGmsQuery = true
                    break
                }
            }
            if (!hasGmsQuery) {
                val pkg = manifest.createElement("package")
                pkg.setAttributeNS("http://schemas.android.com/apk/res/android", "android:name", packageName)
                queries.appendChild(pkg)
                logger.info("Added queries package $packageName for MicroG")
            }
        }
    }
}

@Suppress("unused")
val gmsCoreSupportPatch = bytecodePatch(
    name = "GmsCore support (MicroG)",
    description = "Use MicroG instead of Google Play Services for logins.",
    default = false,
) {
    dependsOn(gmsCoreManifestPatch)

    category("Google Services")
    val gmsCorePackageName by stringOption(
        key = "gmsCorePackageName",
        default = "app.revanced.android.gms",
        title = "MicroG package name",
        description = "Target MicroG package to route GMS calls through",
        values = linkedMapOf(
            "ReVanced GmsCore (app.revanced.android.gms)" to "app.revanced.android.gms",
            "Morphe GmsCore (app.morphe.android.gms)" to "app.morphe.android.gms",
            "Official MicroG (org.microg.gms)" to "org.microg.gms",
            "MG MicroG (com.mgoogle.android.gms)" to "com.mgoogle.android.gms",
            "Google Play Services (com.google.android.gms)" to "com.google.android.gms",
        ),
    )
    val mainActivityClass by stringOption(
        key = "mainActivityClass",
        default = "",
        title = "Main Activity class (optional)",
        description = "Custom main Activity class for injecting startup MicroG checks. Leave empty for auto-detect.",
    )
    val customPackageName by stringOption(
        key = "customPackageName",
        default = "",
        title = "Custom package name (optional)",
        description = "Package name override if the app was renamed via Change Package Name. Leave empty to use manifest package.",
    )

    execute {
        val logger = Logger.getLogger(this::class.java.name)
        val gmsPackage = gmsCorePackageName.orEmpty().trim().ifEmpty { "app.revanced.android.gms" }
        val mainActivity = mainActivityClass.orEmpty().trim()
        val pkgOverride = customPackageName.orEmpty().trim()

        logger.info("GmsCore support: gmsCorePackage=$gmsPackage, mainActivity=${mainActivity.ifEmpty { "<auto>" }}, pkgOverride=${pkgOverride.ifEmpty { "<none>" }}")

        var patched = 0

        // Reuse the simple bypass for GoogleApiAvailability as a baseline
        val fingerprints = listOf(
            GoogleApiAvailabilityContextFingerprint,
            GoogleApiAvailabilityContextVersionFingerprint,
            GoogleApiAvailabilityActivityFingerprint,
            GoogleApiAvailabilityActivityVersionFingerprint,
            GooglePlayServicesUtilContextFingerprint,
        )
        for (fp in fingerprints) {
            val method = fp.methodOrNull ?: continue
            method.addInstructions(
                0,
                """
                const/4 v0, 0x0
                return v0
                """.trimIndent()
            )
            patched++
        }

        // NOTE: removed wasteful full-dex scan for PackageManager.getPackageInfo (was no-op, caused #59 OOM on large apps).
        // The isGooglePlayServicesAvailable bypass above + manifest queries is sufficient for MicroG routing.

        // If a main activity override is provided, ensure it is exported and has MAIN/LAUNCHER
        if (mainActivity.isNotEmpty()) {
            logger.info("Main Activity override configured: $mainActivity  -  ensure it is exported in manifest if needed")
            // Manifest handling for main activity would be done here via resourcePatch, but we keep it as a log for now
            // as most apps auto-detect via <intent-filter> with MAIN/LAUNCHER.
        }

        if (pkgOverride.isNotEmpty()) {
            logger.info("Custom package name override: $pkgOverride  -  Change Package Name patch should be applied first if package was renamed")
        }

        // Also patch GmsClient and related GMS core classes to use the selected MicroG package
        // For now, the isGooglePlayServicesAvailable bypass is the primary enabler; MicroG itself
        // will handle the actual GMS API routing once the package is visible via queries.
        // We log the selected package for debugging.
        logger.info("GmsCore support configured for $gmsPackage  -  ${if (patched > 0) "$patched availability checks bypassed" else "no availability checks found, relying on manifest queries"}")

        if (patched == 0) {
            logger.warning("No Google Play Services availability checks found. Manifest queries for $gmsPackage were still added for MicroG routing.")
        }
    }
}
