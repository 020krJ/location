## [1.1.0](https://gitlab.com/kmru/nai64extrapatches/compare/1.0.0...1.1.0) (2026-10-06)

### Bug Fixes

* install git in the GitLab CI image ([7900b72](https://gitlab.com/kmru/nai64extrapatches/commit/7900b72cf6296652ef72766d42756b295fd9b684))
* use Node 22 for semantic-release in GitLab CI ([f9c930d](https://gitlab.com/kmru/nai64extrapatches/commit/f9c930d0fb6e8ed6f1b939c696b01e620e191b45))
* use reference tags so GitLab accepts the CI config ([0f84003](https://gitlab.com/kmru/nai64extrapatches/commit/0f8400373f3ea5b7b73cb14ac6622874baa421cc))

### New Features

* cover more ad networks and diagnostics from tracker wishlist ([54b924c](https://gitlab.com/kmru/nai64extrapatches/commit/54b924ca0518cd77d7a404c3447516704365f9bf))
* emit adaptive icon with configurable background for Custom App Icon ([3aa33f6](https://gitlab.com/kmru/nai64extrapatches/commit/3aa33f69de7228525877e4562b7cead7b4e150b8))

## 1.0.0 (2026-09-19)

### New Features

* initial Nai's Extra Patches split from Nai64Patches ([7d00972](https://github.com/Nai64/Nai64ExtraPatches/commit/7d00972f763fd3920b2b004cacdab4f5acf6744f))
